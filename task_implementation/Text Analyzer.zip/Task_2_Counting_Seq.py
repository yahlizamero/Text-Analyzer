# Description:
# This file contains the implementation of counting sequences of words from a text input.
# The class CountingSequences uses the input data and saves the results to a JSON file.
import json
from collections import defaultdict
from typing import Dict, Any, List
from task_implementation.Task_1_Preprocessing import Preprocessing
import os
from utils.helper_Task2 import save_to_json, load_data, preprocess_data


class SequenceCounter:
    def __init__(
            self,
            data_file: str = None,
            sentences_path: str = None,
            stopwords_path: str = None,
            preprocess: bool = False
    ):
        """
        Initialize the PersonMentionCounter class.

        :param data_file: Path to the preprocessed JSON file (optional).
        :param sentences_path: Path to the sentences CSV file.
        :param stopwords_path: Path to the stopwords CSV file.
        :param preprocess: Flag indicating if preprocessing is required.
        """
        self.preprocess = preprocess

        if self.preprocess and (not sentences_path or not stopwords_path):
            raise ValueError("Sentences, people, and stopwords paths must be provided if preprocessing is enabled.")

        self.data = (
            self.load_data(data_file)
            if data_file and not preprocess
            else self.preprocess_data()
        )

    def preprocess_data(self) -> Dict[str, Any]:
        """
        Use functions from Task_1_Preprocessing.py to preprocess data if the data wasn't preprocessed already.

        :return: A dictionary containing preprocessed sentences and names.
        """
        # Call external preprocessing functions
        processed_sentences = Preprocessing.preprocess_sentences(self.sentences_path, self.stopwords)

        return {
            "Processed Sentences": processed_sentences,
        }

    @property
    def count_sequences(self) -> Dict[str, List[tuple[str, int]]]:
        """
        Count the occurrence of sequences (1-grams, 2-grams, 3-grams) in the processed sentences.

        :return: A dictionary with sequence sizes as keys and their counts as values.
        """
        sequence_counts = {f"{i}-Seq Counts": defaultdict(int) for i in range(1, self.n + 1)}

        # Extract sentences and count occurrences of each sequence
        for sentence in self.data.get("Question 1", {}).get("Processed Sentences", []):
            for seq_size in range(1, self.n + 1):
                for i in range(len(sentence) - seq_size + 1):
                    seq = tuple(sentence[i:i + seq_size])
                    sequence_counts[f"{seq_size}_seq"][seq] += 1

        # Convert default dict to regular dict and sort alphabetically
        sorted_counts = {
            k: sorted([(" ".join(key), value) for key, value in v.items()], key=lambda x: x[0])
            for k, v in sequence_counts.items()
        }

        return sorted_counts

    def generate_results(self) -> None:
        """
        Generate results for the counted sequences.

        :return: A dictionary containing the results.
        """
        sequence_counts = self.count_sequences
        results = {
            f"Question {self.question_num}": {
                k: v for k, v in sequence_counts.items()
            }
        }
        print(json.dumps(results, indent=4))


if __name__ == "__main__":

    preprocess = False
    sentences_path = "/Users/YAHLIZ/Library/CloudStorage/GoogleDrive-yahli.zamero@mail.huji.ac.il/My Drive/Intro to CS/text_analyzer/examples_new/Q2_examples/example_1/sentences_small_1.csv"
    stopwords_path = "/Users/YAHLIZ/Library/CloudStorage/GoogleDrive-yahli.zamero@mail.huji.ac.il/My Drive/Intro to CS/text_analyzer/Data/REMOVEWORDS.csv"
    data_file = None
    output_file = "/"
    n = 3

    # Check if required files exist
    for file_path in [sentences_path, stopwords_path]:
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"Required file not found: {file_path}")

    result = SequenceCounter(
        preprocess=preprocess,
        sentences_path=sentences_path,
        stopwords_path=stopwords_path,
        data_file=data_file
    )
    # Use the helper function to save the processed data
    save_to_json(output_path=output_file, process_function=result.generate_results)
    print(f"JSON results saved to {output_file}")
