import unittest
from unittest.mock import patch, mock_open
from task_implementation.Task_1_Preprocessing import Preprocessing, load_stopwords_file, clean_text


class TestPreprocessing(unittest.TestCase):

    def setUp(self):
        self.sample_sentences = "sentence\nHarry Potter was here.\nJohn the Potter left the city."
        self.sample_people = "Name,Other Names\nHarry Potter,The Boy Who Lived\nJohn Potter,Johnny"
        self.stopwords = {"was", "the", "left"}

    @patch("builtins.open", new_callable=mock_open, read_data="was\nthe\nleft")
    def test_load_stopwords_file(self, mock_file):
        stopwords = load_stopwords_file("fake_path")
        self.assertEqual(stopwords, {"was", "the", "left"})

    def test_clean_text(self):
        text = "Ha!rry Po-tter was here!"
        cleaned = clean_text(text, self.stopwords)
        self.assertEqual(cleaned, "ha rry po tter here")

    @patch("builtins.open", new_callable=mock_open,
           read_data="sentence\nHarry Potter was here.\nJohn the Potter left the city.")
    def test_preprocess_sentences(self, mock_file):
        preprocessor = Preprocessing(question_num=1, sentences_path="fake_sentences.csv",
                                     stopwords_path="fake_stopwords.txt")
        preprocessor.stopwords = self.stopwords
        result = preprocessor.preprocess_sentences()
        self.assertEqual(result, [["harry", "potter", "here"], ["john", "potter", "city"]])

    @patch("builtins.open", new_callable=mock_open, read_data="sentence\n")
    def test_preprocess_sentences_empty(self, mock_file):
        preprocessor = Preprocessing(question_num=1, sentences_path="fake_sentences2.csv",
                                     stopwords_path="fake_stopwords2.txt")
        preprocessor.stopwords = self.stopwords
        result = preprocessor.preprocess_sentences()
        self.assertEqual(result, [])

    @patch("builtins.open", new_callable=mock_open,
           read_data="Name,Other Names\nHarry Potter,The Boy Who Lived\nJohn Potter,Johnny two shoes")
    def test_preprocess_people(self, mock_file):
        preprocessor = Preprocessing(question_num=1, people_path="fake_people.csv", stopwords_path="fake_stopwords.txt")
        preprocessor.stopwords = self.stopwords
        result = preprocessor.preprocess_people()
        expected_result = [[["harry", "potter"], [["boy", "who", "lived"]]],
                           [["john", "potter"], [["johnny", "two", "shoes"]]]]
        self.assertEqual(result, expected_result)

    @patch("builtins.open", new_callable=mock_open, read_data="Name,Other Names\n")
    def test_preprocess_people_empty(self, mock_file):
        preprocessor = Preprocessing(question_num=1, people_path="fake_people.csv",
                                     stopwords_path="fake_stopwords.txt")
        preprocessor.stopwords = self.stopwords
        result = preprocessor.preprocess_people()
        self.assertEqual(result, [])

    @patch("builtins.open")
    def test_generate_results(self, mock_open_function):
        # Mock file contents for stopwords, sentences, and people
        mock_files = {
            "fake_stopwords.txt": "was\nthe\nleft",
            "fake_sentences.csv": "sentence\nHarry Potter was here.\nJohn the Potter left the city.",
            "fake_people.csv": "Name,Other Names\nHarry Potter,The Boy Who Lived\nJohn Potter,Johnny two shoes"
        }

        # Define the side_effect function to return different mock data based on file path
        def mock_file_open(file, *args, **kwargs):
            return mock_open(read_data=mock_files[file]).return_value

        mock_open_function.side_effect = mock_file_open

        # Initialize the preprocessor
        preprocessor = Preprocessing(
            question_num=1,
            sentences_path="fake_sentences.csv",
            people_path="fake_people.csv",
            stopwords_path="fake_stopwords.txt"
        )

        # Run the generate_results function
        result = preprocessor.generate_results()

        # Expected result
        expected_result = {
            'Question 1': {
                'Processed Sentences': [['harry', 'potter', 'here'], ['john', 'potter', 'city']],
                'Processed Names': [
                    [['harry', 'potter'], [['boy', 'who', 'lived']]],
                    [['john', 'potter'], [['johnny', 'two', 'shoes']]]
                ]
            }
        }

        # Assert that the generated result matches the expected output
        self.assertEqual(result, expected_result)

    @patch("builtins.open")
    def test_generate_results_with_empty_files(self, mock_open_function):
        # Mock empty file contents for stopwords, sentences, and people
        mock_files = {
            "fake_stopwords.txt": "",
            "fake_sentences.csv": "sentence\n",  # Only header, no sentences
            "fake_people.csv": "Name,Other Names\n"  # Only header, no people
        }

        # Define side_effect function to handle multiple files
        def mock_file_open(file, *args, **kwargs):
            return mock_open(read_data=mock_files[file]).return_value

        mock_open_function.side_effect = mock_file_open

        # Initialize the preprocessor
        preprocessor = Preprocessing(
            question_num=1,
            sentences_path="fake_sentences.csv",
            people_path="fake_people.csv",
            stopwords_path="fake_stopwords.txt"
        )

        # Run the generate_results function
        result = preprocessor.generate_results()

        # Expected result for empty input files
        expected_result = {
            'Question 1': {
                'Processed Sentences': [],
                'Processed Names': []
            }
        }

        # Assert that the generated result matches the expected output
        self.assertEqual(result, expected_result)

if __name__ == "__main__":
    unittest.main()