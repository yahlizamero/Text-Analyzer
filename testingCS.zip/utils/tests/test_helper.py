import unittest
from unittest.mock import patch, mock_open
from collections import defaultdict
from utils.helper import preprocess_init, map_n_grams


class TestHelperFunctions(unittest.TestCase):

    @patch("builtins.open", new_callable=mock_open,
           read_data='{"Question 1": {"Processed Sentences": [["hello", "world"]], "Processed Names": [["john", "doe"]]}}')
    def test_preprocess_init_with_preprocessed_file(self, mock_file):
        result = preprocess_init(preprocess_path="fake_preprocessed.json")

        expected = {
            "Processed Sentences": [["hello", "world"]],
            "Processed Names": [["john", "doe"]]
        }

        self.assertEqual(result, expected)

    @patch("builtins.open", new_callable=mock_open, read_data="stopwords\n")
    @patch("os.path.exists", return_value=True)
    @patch("task_implementation.Task_1_Preprocessing.Preprocessing.preprocess_sentences",
           return_value=[["hello", "world"]])
    @patch("task_implementation.Task_1_Preprocessing.Preprocessing.preprocess_people", return_value=[["john", "doe"]])
    def test_preprocess_init_with_raw_data(self, mock_people, mock_sentences, mock_exists, mock_file):
        result = preprocess_init(sentences_path="fake_sentences.csv", people_path="fake_people.csv",
                                 stopwords_path="fake_stopwords.txt")
        expected = {
            "Processed Sentences": [["hello", "world"]],
            "Processed Names": [["john", "doe"]]
        }
        self.assertEqual(result, expected)

    @patch("os.path.exists", return_value=False)
    def test_preprocess_init_missing_file(self, mock_exists):
        with self.assertRaises(FileNotFoundError):
            preprocess_init(sentences_path="missing_sentences.csv", stopwords_path="fake_stopwords.txt")

    def test_preprocess_init_missing_stopwords(self):
        with self.assertRaises(ValueError):
            preprocess_init(sentences_path="fake_sentences.csv")

    def test_map_n_grams_no_N(self):
        sentences = [["hello", "world"], ["hello", "again"]]
        result = map_n_grams(sentences, N=None)
        expected = defaultdict(set, {
            "hello": {tuple(["hello", "world"]), tuple(["hello", "again"])},
            "hello world": {tuple(["hello", "world"])},
            "world": {tuple(["hello", "world"])},
            "hello again": {tuple(["hello", "again"])},
            "again": {tuple(["hello", "again"])}
        })
        self.assertEqual(result, expected)

    def test_map_n_grams_with_N(self):
        sentences = [["the", "quick", "brown", "fox"]]
        result = map_n_grams(sentences, N=2)
        expected = defaultdict(set, {
            "the": {tuple(["the", "quick", "brown", "fox"])},
            "the quick": {tuple(["the", "quick", "brown", "fox"])},
            "quick": {tuple(["the", "quick", "brown", "fox"])},
            "quick brown": {tuple(["the", "quick", "brown", "fox"])},
            "brown": {tuple(["the", "quick", "brown", "fox"])},
            "brown fox": {tuple(["the", "quick", "brown", "fox"])},
            "fox": {tuple(["the", "quick", "brown", "fox"])}
        })
        self.assertEqual(result, expected)

    def test_empty_sentences(self):
        sentences = []
        expected_output = defaultdict(set)
        result = map_n_grams(sentences, N=None)
        self.assertEqual(result, expected_output)

        def test_k_seqs_not_found(self):
            sentences = [
                ["this", "is", "a", "test"],
                ["this", "test", "is", "a", "test"]
            ]
            k_seqs = {
                "not found": ["not", "found"],
                "no match": ["no", "match"]
            }
            sentence_index = map_n_grams(sentences, N=None)
            search_index = defaultdict(set)
            for k_seq_key, k_seq_value in k_seqs.items():
                k_seq_str = " ".join(k_seq_value)
                if k_seq_str in sentence_index:
                    search_index[k_seq_str] = sentence_index[k_seq_str]
            expected_output = {}
            self.assertEqual(search_index, expected_output)

        def test_nested_k_seqs(self):
            sentences = [
                ["this", "is", "a", "test"],
                ["this", "test", "is", "a", "test"]
            ]
            k_seqs = {
                "this is": ["this", "is"],
                "a test": ["a", "test"]
            }
            sentence_index = map_n_grams(sentences, N=None)
            search_index = defaultdict(set)
            for k_seq_key, k_seq_value in k_seqs.items():
                k_seq_str = " ".join(k_seq_value)
                if k_seq_str in sentence_index:
                    search_index[k_seq_str] = sentence_index[k_seq_str]
            expected_output = {
                "this is": {('this', 'is', 'a', 'test')},
                "a test": {('this', 'is', 'a', 'test'), ('this', 'test', 'is', 'a', 'test')}
            }
            self.assertEqual(search_index, expected_output)

if __name__ == "__main__":
    unittest.main()
