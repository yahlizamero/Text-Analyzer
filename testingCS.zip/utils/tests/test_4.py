import unittest
from unittest.mock import patch, mock_open
from collections import defaultdict
from task_implementation.Task_4_Search_Engine import SearchEngine
import json


class TestSearchEngine(unittest.TestCase):

    def setUp(self):
        self.mock_k_seq_data = json.dumps({
            "keys": [["harry", "potter"], ["hogwarts"]]
        })

        self.mock_preprocessed_data = {
            "Processed Sentences": [
                ["harry", "potter", "was", "here"],
                ["welcome", "to", "hogwarts"],
                ["harry", "visited", "hogwarts"]
            ]
        }

        self.mock_sentence_index = defaultdict(set, {
            "harry potter": {("harry", "potter", "was", "here")},
            "hogwarts": {("welcome", "to", "hogwarts"), ("harry", "visited", "hogwarts")}
        })

    @patch("os.path.exists", return_value=True)
    @patch("builtins.open", new_callable=mock_open,
           read_data='{"harry potter": [["harry", "potter"]], "hogwarts": [["hogwarts"]]}')
    @patch("utils.helper.preprocess_init", return_value={
        "Processed Sentences": [
            ["harry", "potter", "was", "here"],
            ["welcome", "to", "hogwarts"],
            ["harry", "visited", "hogwarts"]
        ]
    })
    @patch("task_implementation.Task_4_Search_Engine.map_n_grams", return_value=defaultdict(set, {
        "harry potter": {("harry", "potter", "was", "here")},
        "hogwarts": {("welcome", "to", "hogwarts"), ("harry", "visited", "hogwarts")}
        # there are more keys but all of them have at least one of the sentences above

    }))
    def test_build_search_index(self, mock_map_n_grams, mock_preprocess_init, mock_file, mock_exists):
        engine = SearchEngine(
            question_num=4,
            sentences_path="fake_sentences.csv",
            stopwords_path="fake_stopwords.txt",
            preprocess_path="fake_preprocessed.json",
            k_seq_path="fake_k_seq.json"
        )
        result = engine.build_search_index()
        expected = {
            "harry potter": [["harry", "potter", "was", "here"]],
            "hogwarts": [["harry", "visited", "hogwarts"], ["welcome", "to", "hogwarts"]]
        }
        self.assertEqual(dict(result), expected)

    @patch("os.path.exists", return_value=True)
    @patch("builtins.open", new_callable=mock_open, read_data='{"keys": [["dumbledore"]]}')
    @patch("utils.helper.preprocess_init", return_value={
        "Processed Sentences": [
            ["harry", "potter", "was", "here"],
            ["welcome", "to", "hogwarts"],
            ["harry", "visited", "hogwarts"]
        ]
    })
    @patch("task_implementation.Task_4_Search_Engine.map_n_grams", return_value=defaultdict(set, {
        "harry potter": {("harry", "potter", "was", "here")},
        "hogwarts": {("harry", "visited", "hogwarts"), ("welcome", "to", "hogwarts")}
        # there are more keys but all of them have at least one of the sentences above
    }))
    def test_no_matches(self, mock_map_n_grams, mock_preprocess_init, mock_file, mock_exists):
        engine = SearchEngine(
            question_num=4,
            sentences_path="fake_sentences.csv",
            stopwords_path="fake_stopwords.txt",
            preprocess_path="fake_preprocessed.json",
            k_seq_path="fake_k_seq.json"
        )
        result = engine.build_search_index()
        expected = {}
        self.assertEqual(dict(result), expected)

    @patch("os.path.exists", return_value=True)
    @patch("builtins.open", new_callable=mock_open, read_data='{"keys": [["hogwarts"], ["hogwarts"]]}')
    @patch("utils.helper.preprocess_init", return_value={
        "Processed Sentences": [
            ["harry", "potter", "was", "here"],
            ["welcome", "to", "hogwarts"],
            ["harry", "visited", "hogwarts"]
        ]
    })
    @patch("task_implementation.Task_4_Search_Engine.map_n_grams", return_value=defaultdict(set, {
        "hogwarts": {("welcome", "to", "hogwarts"), ("harry", "visited", "hogwarts")}
        # there are more keys but all of them have at least one of the sentences above

    }))
    def test_duplicate_k_seqs(self, mock_map_n_grams, mock_preprocess_init, mock_file, mock_exists):
        engine = SearchEngine(
            question_num=4,
            sentences_path="fake_sentences.csv",
            stopwords_path="fake_stopwords.txt",
            preprocess_path="fake_preprocessed.json",
            k_seq_path="fake_k_seq.json"
        )
        result = engine.build_search_index()
        expected = {
            "hogwarts": [["harry", "visited", "hogwarts"], ["welcome", "to", "hogwarts"]]
        }
        self.assertEqual(dict(result), expected)

    @patch("os.path.exists", return_value=True)
    @patch("builtins.open", new_callable=mock_open, read_data='{"keys": []}')
    @patch("utils.helper.preprocess_init", return_value={
        "Processed Sentences": [
            ["harry", "potter", "was", "here"],
            ["welcome", "to", "hogwarts"],
            ["harry", "visited", "hogwarts"]
        ]
    })
    @patch("task_implementation.Task_4_Search_Engine.map_n_grams", return_value=defaultdict(set, {
        "harry potter": {("harry", "potter", "was", "here")},
        "hogwarts": {("harry", "visited", "hogwarts"), ("welcome", "to", "hogwarts")}
    }))
    def test_empty_k_seq(self, mock_map_n_grams, mock_preprocess_init, mock_file, mock_exists):
        """Test behavior when k_seq_path is empty."""
        engine = SearchEngine(
            question_num=4,
            sentences_path="fake_sentences.csv",
            stopwords_path="fake_stopwords.txt",
            preprocess_path="fake_preprocessed.json",
            k_seq_path="fake_k_seq.json"
        )
        result = engine.build_search_index()
        expected = {}  # Since there are no sequences in k_seq_path, the result should be empty
        self.assertEqual(dict(result), expected)


if __name__ == "__main__":
    unittest.main()
